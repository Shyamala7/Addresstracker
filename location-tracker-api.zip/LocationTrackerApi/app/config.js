module.exports = {

    'secret': 'locationtracker',

};